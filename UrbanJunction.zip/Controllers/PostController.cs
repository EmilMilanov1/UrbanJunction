﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

[Authorize]
public class PostController : Controller
{
    private readonly ForumDbContext _context;

    public PostController(ForumDbContext context)
    {
        _context = context;
    }

    [AllowAnonymous]
    public async Task<IActionResult> Index()
    {
        var posts = await _context.Posts.Include(p => p.Category).Include(p => p.User).ToListAsync();
        return View(posts);
    }

    [AllowAnonymous]
    public async Task<IActionResult> Details(int id)
    {
        var post = await _context.Posts
            .Include(p => p.Category)
            .Include(p => p.User)
            .Include(p => p.Comments)
            .ThenInclude(c => c.User)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (post == null) return NotFound();
        return View(post);
    }

    public IActionResult Create()
    {
        ViewBag.Categories = _context.Categories.ToList();
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Create(Post post)
    {
        if (!ModelState.IsValid)
        {
            ViewBag.Categories = _context.Categories.ToList();
            return View(post);
        }

        post.UserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        post.CreatedOn = DateTime.UtcNow;
        _context.Posts.Add(post);
        await _context.SaveChangesAsync();
        TempData["Success"] = "Post created.";
        return RedirectToAction(nameof(Index));
    }
}
