﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Xml.Linq;

[Route("api/[controller]")]
[ApiController]
public class CommentApiController : ControllerBase
{
    private readonly ForumDbContext _context;

    public CommentApiController(ForumDbContext context)
    {
        _context = context;
    }

    [HttpGet("{postId}")]
    public async Task<IActionResult> GetComments(int postId)
    {
        var comments = await _context.Comments
            .Where(c => c.PostId == postId)
            .Include(c => c.User)
            .OrderByDescending(c => c.CreatedOn)
            .ToListAsync();

        return Ok(comments.Select(c => new
        {
            c.Id,
            c.Content,
            User = c.User.DisplayName,
            c.CreatedOn
        }));
    }

    [Authorize]
    [HttpPost]
    public async Task<IActionResult> PostComment([FromBody] Comment comment)
    {
        comment.CreatedOn = DateTime.UtcNow;
        comment.UserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        _context.Comments.Add(comment);
        await _context.SaveChangesAsync();

        return Ok(new { success = true });
    }
}
