﻿namespace HouseRentingSystem.Web.Models.Home
{
    public class HouseIndexViewModel
    {
        public string Title { get; set; } = null!;

        public string ImageUrl { get; set; } = null!;
    }
}
