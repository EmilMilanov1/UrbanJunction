﻿namespace HouseRentingSystem.Data.Constants
{
    public class DataConstants
    {
        public class HouseConstants
        {
            // Because I said so
            public const int TitleMaxLength = 50;
        }
    }
}
